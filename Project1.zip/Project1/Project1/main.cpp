#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
using namespace std;

//Prototype functions
void ReadFromFile();
double calculateDistance(double, double, double, double);
double calculateRadius(double, double, double, double);
double calculateCircumfrence(double r);
double calculateArea(double r);

//Global variable for pi
const double PI = 3.14159;

//main class
int main()
{	
	ReadFromFile();
	
	cin.get();
	return 0;
}//end main

//function statements
void ReadFromFile()
{
	ifstream infile;
	double radius;
	int i = 1;
	infile.open("input.txt");
	int x1,x2,y1,y2;

	while(!infile.eof())
	{
		infile >> x1 >> x2 >> y1 >> y2;
		radius =  calculateRadius(x1,x2,y1,y2);
		cout << fixed << showpoint;
		cout << "Circle " << i << ":" << endl; 
		cout << "\tRadius: " << setprecision(2) << radius << " m" <<endl;
		cout << "\tCircumfrence: " << setprecision(2) << calculateCircumfrence(radius) << " m" << endl;
		cout << "\tArea: " << setprecision(2) << calculateArea(radius) << " m^2" << endl;
		i++;
	}//end while loop
	infile.close();
}//end readFromFile

//Finding distance
double calculateDistance(double x1, double y1, double x2, double y2)
{
	return sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
}

//Finding radius
double calculateRadius(double x1, double y1, double x2, double y2)
{
	return calculateDistance(x1, y1, x2, y2);
}

//Finding circumfrence
double calculateCircumfrence(double r)
{
	return (2 * PI * r);
}

//Finding area
double calculateArea(double r)
{
	return (PI * pow(r, 2));
}